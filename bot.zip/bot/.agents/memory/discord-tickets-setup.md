---
name: Discord Tickets setup quirks
description: Non-obvious constraints discovered while setting up discord-tickets/bot on Replit
---

## Node.js version
Must be Node 20+. `fast-jwt@5.x` (pulled by `@fastify/jwt@^9`) requires >=20 and is also blocked by Replit's security firewall (Critical CVE). Fix: bump `@fastify/jwt` to `^10.0.0` in package.json (v10 uses `fast-jwt@^6.x` which is allowed).

**Why:** The project's package.json originally declared `@fastify/jwt@^9.0.4`, which resolves to fast-jwt 5.x — both incompatible with Node 18 and blocked by the package firewall.

**How to apply:** If fast-jwt is ever blocked again, check which @fastify/* package is pulling it in and bump to the latest major.

## ENCRYPTION_KEY
Must be stored as a **Replit Secret**, not a plain env var. The app validates it must be ≥48 characters. Generate with: `node -e "const c=require('crypto'); console.log(c.randomBytes(32).toString('hex'));"` (produces 64 hex chars).

**Why:** setEnvVars writes to .replit which is committed to source control — a cryptographic key there is a security vulnerability. The code reviewer flagged this as severe.

## Privileged Gateway Intents
The Discord bot requires all three Privileged Gateway Intents enabled in Discord Developer Portal → Bot → Privileged Gateway Intents (Presence, Server Members, Message Content). Without them the bot crashes on connect with "Used disallowed intents".

## Web panel OAuth login
The "Continue with Discord" button on the web panel requires `<HTTP_EXTERNAL>/auth/callback` registered as a redirect URI in Discord Developer Portal → OAuth2.

## Postinstall script
`scripts/postinstall.js` runs automatically after `npm install`. It copies the correct Prisma schema from `db/<provider>/` to `prisma/`, then runs `prisma generate` + `prisma migrate deploy`. Requires `DB_PROVIDER` env var to be set before install. For sqlite, `DB_CONNECTION_URL` auto-defaults to `file:<cwd>/user/database.db`.
